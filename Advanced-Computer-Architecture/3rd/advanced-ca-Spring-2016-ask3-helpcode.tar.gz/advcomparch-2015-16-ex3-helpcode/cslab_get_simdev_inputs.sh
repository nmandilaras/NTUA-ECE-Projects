#!/bin/bash

## This script is only intended to be executed inside the PARSEC main dir
if [ ! -f .parsec_uniquefile ]; then
	echo "Please run this script inside the PARSEC main dir."
	exit 1
fi

## You can change these if you want.
WORKSPACE_DIR=./parsec_workspace
## If you change this remember to also modify cmds_simdev.txt file
inputs_dir=${WORKSPACE_DIR}/inputs-simdev

mkdir -p ${inputs_dir}
for benchDir in `ls -d pkgs/{apps,kernels}/*`; do
	benchName=$(echo $benchDir | cut -d/ -f3)
	echo $benchName
	cp $benchDir/inputs/input_simdev.tar ${inputs_dir}/$benchName-input_simdev.tar

	WD=$(pwd)
	cd ${inputs_dir}
	tar xvf $benchName-input_simdev.tar
	cd $WD

	rm ${inputs_dir}/$benchName-input_simdev.tar
done
