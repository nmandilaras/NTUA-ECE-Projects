#!/bin/bash

SNIPER_DIR="/path/to/sniper-6.1"
SNIPER_CFG="gainestown"
CMDS_FILE="./cmds_simdev.txt"
outMainDir="./sniper-outputs/"

SNIPER_EXE=${SNIPER_DIR}/run-sniper

for BENCH in $@; do
	cmd=$(cat ${CMDS_FILE} | grep "$BENCH")

	benchOutDir=$outMainDir/$BENCH
	mkdir -p $benchOutDir

for dw in 1 2; do
for ws in 1 2 4; do
	outDir=$(printf "%s.DW_%02d-WS_%03d.out" $BENCH $dw $ws)
	outDir="$benchOutDir/$outDir"

	sniper_cmd="$SNIPER_EXE -c $SNIPER_CFG -d $outDir --roi -g --perf_model/core/interval_timer/dispatch_width=$dw -g --perf_model/core/interval_timer/window_size=$ws -- $cmd"
	time $sniper_cmd
done
done

done
