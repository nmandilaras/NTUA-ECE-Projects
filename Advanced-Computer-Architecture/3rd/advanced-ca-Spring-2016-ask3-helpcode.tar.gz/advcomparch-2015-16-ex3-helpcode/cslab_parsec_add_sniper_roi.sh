#!/bin/bash

## This script is only intended to be executed inside the PARSEC main dir
if [ ! -f .parsec_uniquefile ]; then
	echo "Please run this script inside the PARSEC main dir."
	exit 1
fi

## Please change this to show your sniper's path e.g. /home/user/sniper-6.1
SNIPER_DIR=/path/to/sniper-6.1

## Let's add sniper's SimRoiStart() and SimRoiEnd() on parsec hooks.
parsec_hooks_src_file="pkgs/libs/hooks/src/hooks.c"
if [ ! -f $parsec_hooks_src_file ]; then
	echo "Could not locate file $parsec_hooks_src_file"
	exit 1
fi

## First check whether they are already present.
grep "SimRoiStart" $parsec_hooks_src_file && echo "a SimRoiStart() call seem to be already in $parsec_hooks_src_file" && exit 1
grep "SimRoiEnd" $parsec_hooks_src_file && echo "a SimRoiEnd() call seem to be already in $parsec_hooks_src_file" && exit 1

## Create a temporary file which will finaly replace parsec hooks file
tmpfile=$(mktemp)
echo "#include \"$SNIPER_DIR/include/sim_api.h\"" > $tmpfile
cat $parsec_hooks_src_file | \
     awk '{print} 
	      /void __parsec_roi_begin()/ { print "  SimRoiStart();"}
	      /void __parsec_roi_end()/ { print "  SimRoiEnd();"}
	     ' >> $tmpfile

## Keep a copy of the old parsec hooks file and replace with the temporary
cp $parsec_hooks_src_file ${parsec_hooks_src_file}.old
mv $tmpfile $parsec_hooks_src_file

## Now let's uninstall and recompile the hooks library
./bin/parsecmgmt -a uninstall -c gcc-serial -p hooks
./bin/parsecmgmt -a build -c gcc-serial -p hooks

exit 0
